plotExposedPeriodsInt <- function(r, pe)
 {
  if ((length(r) != 1L) || is.na(r) || (r < 1) || (floor(r) != ceiling(r)))
    stop("r' must be a positive integer")
  
  if ((length(pe) != 1L) || is.na(pe) || (pe <= 0) || (pe >= 1))
    stop("'pe' must be in (0, 1)")
  
  plotExposedPeriods(r = r, pe = pe, rhoe = 0.5)
  
  plot.maybe <- function(...) if (as.numeric(tclObj(SliderValue)) != slider.sav) plot.rhoe()
  plot.rhoe <- function(...)
   {
   	slider.sav <- as.numeric(tclObj(SliderValue))
    eval(plotExposedPeriods(r = r, pe = pe, rhoe = as.numeric(tclObj(SliderValue))))
   }
  prevVec <- rep(pe, r + 1)
  tt <- tktoplevel()
  SliderValue <- tclVar("0.5")
  slider.sav <- 0.5
  SliderValueLabel <- tklabel(tt, text = as.character(tclvalue(SliderValue)))
  tkgrid(tklabel(tt,text="rho_e :"), SliderValueLabel, tklabel(tt))
  tkconfigure(SliderValueLabel, textvariable = SliderValue)
  slider <- tkscale(tt, from = lowerrhoe(r, prevVec), to = 1, showvalue = F, variable = SliderValue,
                   resolution = 0.01, orient = "vertical", command = plot.maybe)
  tkgrid(slider)
  tkfocus(tt)
 }