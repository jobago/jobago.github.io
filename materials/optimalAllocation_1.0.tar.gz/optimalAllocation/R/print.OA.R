print.OA <-
function(x, ...)
 {
  if(!inherits(x, "OA"))
   stop("argument 'x' must be of class 'OA'")
  
  if (x$parameters$rMax == 0)
   {
   	cat("  Results subject to a cross-sectional design:\n") } else {
    cat("  Results subject to r not greater than ", x$parameters$rMax, ":\n", sep="")
   }

  cat("----------------------------------------------------- \n")
  if (x$parameters$rMax > 0)
   cat("Optimal total number of measurements (r+1):", x$ropt + 1, "\n")
   
  if (x$parameters$rMax == 0)
   {
   	cat("Number of participants (N):", x$Nopt, "\n") } else {
    cat("Optimal number of participants (N)        :", x$Nopt, "\n")
   }

  if (comment(x) == "maxPower")
   {
    if (x$parameters$rMax == 0)
     {
   	  cat("Power                     :", x$maxPower, "\n") } else {
      cat("Maximized power                           :", x$maxPower, "\n") } } else {
      	
    if (x$parameters$rMax == 0)
     {
   	  cat("Cost                      :", x$minCost, "\n") } else {
      cat("Minimized cost                            :", x$minCost, "\n") }
   }
 }
