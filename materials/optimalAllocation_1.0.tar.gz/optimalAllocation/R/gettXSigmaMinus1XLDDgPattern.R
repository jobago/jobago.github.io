gettXSigmaMinus1XLDDgPattern <-
function(r, rg, theta, rho, sigma2, rhoe, pe)
 {
  # SigmaMinus1:
  if (rg == 0)
   {
    res <- (1/sigma2) * matrix(c(    1, 0, pe[1], 0,
                                     0, 0,     0, 0,
                                 pe[1], 0, pe[1], 0,
                                     0, 0,     0, 0),
                                nrow=4, ncol=4) } else {
    Sigma <- sigma2*toeplitz(c(1, rho^(((1:rg)/r)^theta)))
    SigmaMinus1 <- solve(Sigma)
    # omega00:
    w00 <- sum(SigmaMinus1)
    # omega10:
    jPowers <- matrix(0:rg, nrow=1+rg, ncol=1+rg)
    w10 <- sum(jPowers*SigmaMinus1)
    # omega11:
    aux1 <- expand.grid(y=(0:rg), x=(0:rg))
    aux1 <- apply(aux1, 1, prod)
    jkPowers <- matrix(aux1, nrow=1+rg, ncol=1+rg)
    w11 <- sum(jkPowers*SigmaMinus1)
    # eta1:
    p <- pe[1:(rg+1)]
    expectedEstar <- cumsum(c(0, p[-1]))
    expectedEstar <- expectedEstar/r  
    expectedEstarMatrix <- matrix(expectedEstar, nrow=1+rg, ncol=1+rg)
    eta1 <- sum(SigmaMinus1*expectedEstarMatrix)
    # eta2:
    eta2 <- sum(t(jPowers)*SigmaMinus1*expectedEstarMatrix)
    # eta3:
    re <- matrix(rhoe, nrow=rg+1, ncol=rg+1)
    diag(re) <- 1
    v <- p*(1 - p)
    expectedElEm <- re*sqrt(v %*% t(v)) + p %*% t(p)
    expectedElEm <- expectedElEm[-1, -1]
    if (class(expectedElEm) == "numeric") expectedElEm <- as.matrix(expectedElEm)
    expectedEjStarEkStar <- matrix(0, nrow=rg, ncol=rg)
    for (i in 1:rg)
     {
   	  for (j in 1:rg)
   	   expectedEjStarEkStar[i, j] <- sum(expectedElEm[1:i, 1:j])
     }
    eta3 <- SigmaMinus1[-1, -1]*expectedEjStarEkStar
    eta3 <- sum(eta3)/r^2
    # Ei0eta1:
    expectedEi0EjStar <- rhoe*sqrt(p[1]*(1 - p[1])*p*(1 - p)) + p[1]*p
    expectedEi0EjStar[1] <- 0
    expectedEi0EjStarMatrix <- matrix(cumsum(expectedEi0EjStar), nrow=1+rg, ncol=1+rg)
    Ei0eta1 <- sum(SigmaMinus1*expectedEi0EjStarMatrix)/r
    res <- matrix(c(      w00,         w10/r,         pe[1]*w00,         eta1,
                        w10/r,       w11/r^2,       pe[1]*w10/r,       eta2/r,
                    pe[1]*w00,   pe[1]*w10/r,         pe[1]*w00,      Ei0eta1,
                         eta1,        eta2/r,           Ei0eta1,         eta3),
                  nrow=4, ncol=4, byrow=TRUE)
   }
  res
 }
