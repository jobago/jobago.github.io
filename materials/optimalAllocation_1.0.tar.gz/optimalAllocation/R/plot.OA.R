plot.OA <-
function(x, Ncex = 0.7, ...)
 {
  if(!inherits(x, "OA"))
   stop("argument 'x' must be of class 'OA'")
  
  if(x$parameters$rMax == 0)
   {
    cat("Nothing to plot for a cross-sectional design\n") } else {
    
    if (comment(x) == "maxPower")
     {
   	  y <- x$f$power
   	  laby <- "Power (N)" } else {
   	  y <- x$f$cost
   	  laby <- "Cost (N)"
     }
    delta <- (max(y) - min(y))/10
  
    if (comment(x) == "maxPower")
     {
   	  maxy <- max(y) + delta } else {
   	  maxy <- max(y)
     }

    par(las=1)
    plot(x$f$r + 1, y, type = "b", xlab = "Total number of measurements per participant", ylab = laby, xaxt="n", pch="", ylim=c(min(y), maxy))
    text(x$f$r + 1, y, paste("(", x$f$N, ")", sep=""), cex = Ncex)
    axis(1, at=1:(x$parameters$rMax + 1))
      if (comment(x) == "maxPower")
     {
   	  arrows(x$ropt + 1, max(y) + (max(y) - min(y))/10, x$ropt + 1, max(y) + (max(y) - min(y))/20, length=0.1, code=2, lwd=2) } else {
   	  arrows(x$ropt + 1, min(y) + (max(y) - min(y))/10, x$ropt + 1, min(y) + (max(y) - min(y))/20, length=0.1, code=2, lwd=2)
     }
   }
 }
