summary.OA <-
function(object, ...)
 {
  if(!inherits(object, "OA"))
   stop("argument 'object' must be of class 'OA'")
  res <- object
  attr(res, "class") <- NULL
  res
 }
