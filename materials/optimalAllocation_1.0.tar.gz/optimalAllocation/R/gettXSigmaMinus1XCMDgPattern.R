gettXSigmaMinus1XCMDgPattern <-
function(r, rg, theta, rho, sigma2, rhoe, pe)
 {
  # SigmaMinus1:
  if (rg == 0) Sigma <- sigma2 else Sigma <- sigma2*toeplitz(c(1, rho^(((1:rg)/r)^theta)))
  SigmaMinus1 <- solve(Sigma)
  # omega00:
  w00 <- sum(SigmaMinus1)
  # omega10:
  jPowers <- matrix(0:rg, nrow=1+rg, ncol=1+rg)
  w10 <- sum(jPowers*SigmaMinus1)
  # omega11:
  aux1 <- expand.grid(y=(0:rg), x=(0:rg))
  aux1 <- apply(aux1, 1, prod)
  jkPowers <- matrix(aux1, nrow=1+rg, ncol=1+rg)
  w11 <- sum(jkPowers*SigmaMinus1)
  # phi0:
  p <- pe[1:(rg+1)]
  #kpowers <- matrix(rep((0:rg)^q, rg+1), nrow=rg+1, byrow=TRUE)
  ps <- matrix(rep(p, rg+1), nrow=rg+1, byrow=FALSE)
  phi0 <- sum(SigmaMinus1*ps)
  # phi1:
  kPowers <- t(jPowers)
  peMatrix <- matrix(rep(p, rg+1), nrow=rg+1, byrow=FALSE)
  phi1 <- sum(kPowers*SigmaMinus1*peMatrix)
  # epsilon:
  re <- matrix(rhoe, nrow=rg+1, ncol=rg+1)
  diag(re) <- 1
  v <- p*(1 - p)
  epsilon <- sum(SigmaMinus1*(re*sqrt(v %*% t(v)) + p %*% t(p)))
  matrix(c(w00,        w10/r,      phi0,
           w10/r,      w11/r^2,    phi1/r,
           phi0,       phi1/r,     epsilon),
           nrow=3, ncol=3, byrow=TRUE)
 }
