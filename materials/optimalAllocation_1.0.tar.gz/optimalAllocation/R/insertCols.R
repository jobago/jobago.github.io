insertCols <- function(m, i, j, xi, xj)
 {
  nrows <- nrow(m)
  ncols <- ncol(m)
  newm <- matrix(0, nrow = nrows, ncol = ncols + 2)
  newm[, i] <- xi
  newm[, j] <- xj
  if (i > 1)
   {
    newm[, 1:(i - 1)] <- m[, 1:(i - 1)]
	if (i < (ncols + 1))
	 {
	  if (j - i > 1)
	   {
	   	newm[, ( i + 1):(j - 1)] <- m[, i:(j - 2)]
	    if (j < (ncols + 2)) newm[,(j+1):(ncols+2)]=m[,(j-1):ncols]
	    } else {
	            newm[, (j + 1):(ncols + 2)] <- m[, i:ncols]
	           }
	  }
    } else {
    	    if (j - i > 1)
    	     {
    	      newm[, (i + 1):(j - 1)] <- m[, 1:(j - i - 1)]
    	      if (j < (ncols + 2)) newm[, (j + 1):(ncols + 2)] <- m[, (j - i):ncols]
    	     } else {
    	     	     newm[, (j + 1):(ncols + 2)] <- m[, 1:ncols]
    	     	    }
    	   }
  newm
 }
