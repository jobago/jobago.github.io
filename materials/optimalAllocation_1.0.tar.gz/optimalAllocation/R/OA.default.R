OA.default <-
function(target, pattern, rMax = 20, theta = NULL, rho = NULL, sigma2, rhoe = NULL, pe0, per = NULL, piM = NULL, kappa = NULL, budget = NULL, c1, reqPower = NULL, beta, alpha = 0.05)
 {
  if ((target != "maxPower") && (target != "minCost"))
     stop("'target' must be 'maxPower' or 'minCost'")
   
  if ((pattern != "CMD") && (pattern != "LDD"))
     stop("'pattern' must be 'CMD' or 'LDD'")
     
  if ((pattern == "CMD") &&  ((length(rMax) != 1L) || is.na(rMax) || (rMax < 0) || (floor(rMax) != ceiling(rMax))))
     stop("rMax' must be a nonnegative integer if pattern is 'CMD'")
   
  if ((pattern == "LDD") &&  ((length(rMax) != 1L) || is.na(rMax) || (rMax < 1) || (floor(rMax) != ceiling(rMax))))
     stop("rMax' must be a positive integer if pattern is 'LDD'")
     
  if ((rMax != 0) && ((length(theta) != 1L) || is.na(theta) || (theta < 0) || (theta > 1)))
     stop("'theta' must be in [0, 1]")
   
  if ((rMax != 0) && ((length(rho) != 1L) || is.na(rho) || (rho < 0) || (rho >= 1)))
     stop("'rho' must be in [0, 1)")
   
  if ((length(sigma2) != 1L) || is.na(sigma2) || (sigma2 <= 0))
     stop("'sigma2' must be a positive number")
   
  if ((rMax != 0) && ((length(rhoe) != 1L) || is.na(rhoe) || (rhoe < 0) || (rhoe > 1)))
     stop("'rhoe' must be in [0, 1]")
   
  if ((length(pe0) != 1L) || is.na(pe0) || (pe0 <= 0) || (pe0 >= 1))
     stop("'pe0' must be in (0, 1)")

  if ((rMax != 0) && ((length(per) != 1L) || is.na(per) || (per <= 0) || (per >= 1)))
     stop("'per' must be in (0, 1)")

  if ((rMax != 0) && (rhoe == 1) && (per != pe0))
     stop("If 'rhoe' is equal to 1 then 'per' must be equal to 'pe0'")
      
  if ((rMax != 0) && ((length(per) != 1L) || is.na(per) || (per <= 0) || (per >= 1)))
     stop("'per' must be in (0, 1)")
    
  if ((rMax != 0) && ((length(piM) != 1L) || is.na(piM) || (piM < 0) || (piM >= 1)))
     stop("'piM' must be in [0, 1)")
   
  if ((rMax != 0) && ((length(kappa) != 1L) || is.na(kappa) || (kappa < 1)))
     stop("'kappa' must be equal or greater than 1")
     
  if ((length(c1) != 1L) || is.na(c1) || (c1 <= 0))
     stop("'c1' must be a positive number")
   
  if ((length(beta) != 1L) || is.na(beta))
     stop("'beta' must be a number") 
   
  if ((length(alpha) != 1L) || is.na(alpha) || (alpha <= 0) || (alpha >= 1))
     stop("'alpha' must be in (0, 1)") 
       
  if (target == "maxPower")
   {
    if ((length(budget) != 1L) || is.na(budget) || (budget <= 0))
       stop("'budget' must be a positive number")
     
    if (budget < c1)
     stop("'c1' can't be greater than 'budget'") } else {
   	
    if ((length(reqPower) != 1L) || is.na(reqPower) || (reqPower <= 0) || (reqPower >= 1))
     stop("'reqPower' must be in (0, 1)")	
   }

  res <- NULL
  z <- qnorm(1 - alpha/2)
  if (rMax == 0)
   {
    res$ropt <- 0
    if (target == "maxPower")
     {
  	  res$Nopt <- floor(budget/c1)
  	  res$maxPower <- pnorm(abs(beta)*sqrt(res$Nopt*pe0*(1 - pe0)/sigma2) - z)
  	  res$cost <- res$Nopt*c1 } else {
  	  	
  	  res$Nopt <- ceiling(sigma2*(z + qnorm(reqPower))^2/(pe0*(1 - pe0)*beta^2))
  	  if (res$Nopt < 1)
  	   stop("Insufficient budget")	

      res$minCost <- res$Nopt*c1 
      res$power <- pnorm(abs(beta)*sqrt(res$Nopt*pe0*(1 - pe0)/sigma2) - z) 
     }
    res$sdBeta <- sqrt(sigma2/(res$Nopt*pe0*(1 - pe0)))
    f <- data.frame(r = 0, N = res$Nopt)
    if (target == "maxPower")
     {
  	  f$power <- res$power
  	  res$parameters <- data.frame(target = target, pattern = pattern, rMax = rMax, sigma2 = sigma2, pe0 = pe0, budget = budget, c1 = c1, beta = beta, alpha = alpha) } else {
  	  f$cost <- res$cost
  	  res$parameters <- data.frame(target = target, pattern = pattern, rMax = rMax, sigma2 = sigma2, pe0 = pe0, reqPower = reqPower, c1 = c1, beta = beta, alpha = alpha)
     } 
    } else {
    rvector <- 1:rMax 
    if ((pattern == "CMD") && (theta == 0) && (rhoe == rho) && (per == pe0) && (piM == 0) && (kappa == 1))
     {
      sdBetavector <- sqrt(sigma2/(pe0 * (1 - pe0) * (rvector + 1))) } else {
      sdBetavector <- rep(NA, rMax)
      for (i in 1:length(rvector))
       {
        peSeq <- seq(pe0, per, length.out=rvector[i] + 1)
        sdBetavector[i] <- getSdBetaSubBgPattern(pattern = pattern, r = rvector[i], theta = theta, rho = rho, sigma2 = sigma2, rhoe = rhoe, pe = peSeq, piM = piM)
       }
      }
      if (pattern == "CMD")
       {
   	    rvector <- c(0, rvector)
        sdBetavector <- c(sqrt(sigma2/(pe0 * (1 - pe0))), sdBetavector)
       }
    unconstrainedF <- (kappa + rvector)*sdBetavector^2
    res$roptreal <- rvector[which(unconstrainedF == min(unconstrainedF))[1]]
    if (piM == 0)
     {
   	  term <- rvector } else {
   	  	
   	  term <- piM/((1 - piM)^(-1/rvector) - 1)
     }
    if (target == "maxPower")
     {
  	  Nvector <- floor(budget/(c1*(1 + term/kappa)))
  	  powervector <- pnorm(abs(beta)*sqrt(Nvector)/sdBetavector - z)
  	  idNnotless1 <- Nvector >= 1
  	  Nvector <- Nvector[idNnotless1]
      rvector <- rvector[idNnotless1]
      sdBetavector <- sdBetavector[idNnotless1]
      term <- term[idNnotless1]
      powervector <- powervector[idNnotless1]
  	  idOpt <- which(powervector == max(powervector))[1] 
      res$ropt <- rvector[idOpt]
      res$Nopt <- Nvector[idOpt]
  	  res$maxPower <- powervector[idOpt]
  	  res$cost <- res$Nopt*c1*(1 + term[idOpt]/kappa) } else {
  	  	
  	  Nvector <- ceiling(((sdBetavector/abs(beta))*(z + qnorm(reqPower)))^2)
  	  costvector <- Nvector*c1*(1 + term/kappa)
  	  idNnotless1 <- Nvector >= 1
  	  Nvector <- Nvector[idNnotless1]
      rvector <- rvector[idNnotless1]
      sdBetavector <- sdBetavector[idNnotless1]
      term <- term[idNnotless1]
      costvector <- costvector[idNnotless1]
  	  idOpt <- which(costvector == min(costvector))[1] 
  	  res$ropt <- rvector[idOpt]
      res$Nopt <- Nvector[idOpt]
      res$minCost <- costvector[idOpt]
      res$power <- pnorm(abs(beta)*sqrt(res$Nopt)/sdBetavector[idOpt] - z) 
     }
   res$sdBeta <- sdBetavector[idOpt]/sqrt(res$Nopt)
   f <- data.frame(r = rvector, N = Nvector)
    if (target == "maxPower")
   {
  	f$power <- powervector
  	res$parameters <- data.frame(target = target, pattern = pattern, rMax = rMax, theta = theta, rho = rho, sigma2 = sigma2, rhoe = rhoe, pe0 = pe0, per = per, piM = piM, kappa = kappa, budget = budget, c1 = c1, beta = beta, alpha = alpha) } else {
  	f$cost <- costvector
  	res$parameters <- data.frame(target = target, pattern = pattern, rMax = rMax, theta = theta, rho = rho, sigma2 = sigma2, rhoe = rhoe, pe0 = pe0, per = per, piM = piM, kappa = kappa, reqPower = reqPower, c1 = c1, beta = beta, alpha = alpha)
    }
   }
  res$f <- f
  class(res) <- "OA"
  comment(res) <- target
  res
 }
