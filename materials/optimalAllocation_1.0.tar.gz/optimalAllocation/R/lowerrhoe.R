lowerrhoe <- function(r, peVec)
 {
  meanpe <- mean(peVec)
  lower <- -1/r + (((r + 1) * meanpe - floor((r + 1) * meanpe)) * (1 - (r + 1) * meanpe + floor((r + 1) * meanpe))) /
		(r * (r + 1) * meanpe * (1 - meanpe))
  lower
 }
