gettXSigmaMinus1XgPattern <-
function(pattern, r, rg, theta, rho, sigma2, rhoe, pe)
 {
  if (pattern == "CMD")
  {
   gettXSigmaMinus1XCMDgPattern(r=r, rg=rg, theta=theta, rho=rho, sigma2=sigma2, rhoe=rhoe, pe=pe) } else {
   gettXSigmaMinus1XLDDgPattern(r=r, rg=rg, theta=theta, rho=rho, sigma2=sigma2, rhoe=rhoe, pe=pe)
  } 
 }
