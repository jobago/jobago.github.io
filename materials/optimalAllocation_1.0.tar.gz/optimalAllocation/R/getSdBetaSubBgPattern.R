getSdBetaSubBgPattern <-
function(pattern, r, theta, rho, sigma2, rhoe, pe, piM)
 {
  if (piM == 0 | r == 0)
   {
   	res <- gettXSigmaMinus1XgPattern(pattern=pattern, r=r, rg=r, theta=theta, rho=rho, sigma2=sigma2, rhoe=rhoe, pe=pe)
    } else {
            pim <- 1 - (1 - piM)^(1/r)
            # Last term of the sum:
            res <- (1 - piM)*gettXSigmaMinus1XgPattern(pattern=pattern, r=r, rg=r, theta=theta, rho=rho, sigma2=sigma2, rhoe=rhoe, pe=pe)
            for (g in 1:r)
             res <- res + pim*(1 - piM)^((g - 1)/r)*gettXSigmaMinus1XgPattern(pattern=pattern, r=r, rg=g-1, theta=theta, rho=rho, sigma2=sigma2, rhoe=rhoe, pe=pe)
    }
  res <- sqrt(solve(res)[nrow(res), ncol(res)])
  res
 }
