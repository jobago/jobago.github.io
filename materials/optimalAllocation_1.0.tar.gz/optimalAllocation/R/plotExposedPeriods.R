plotExposedPeriods <- function(r, pe, rhoe, eps = 0.001, maxIter = 1000)
 {
  if ((length(r) != 1L) || is.na(r) || (r < 1) || (floor(r) != ceiling(r)))
     stop("r' must be an integer not smaller than 1")
  
  if ((length(pe) != 1L) || is.na(pe) || (pe <= 0) || (pe >= 1))
     stop("'pe' must be in (0, 1)")
  
  if ((length(rhoe) != 1L) || is.na(rhoe) || (rhoe < -1) || (rhoe > 1))
     stop("'rhoe' must be in [-1, 1]")
  
  lowrhoe <- lowerrhoe(r = r, peVec = rep(pe, r + 1))
  
  if (rhoe < lowrhoe)
     stop(paste("for actual values of 'r' and 'pe', 'rhoe' can't be smaller than", lowrhoe))
     
  if ((length(eps) != 1L) || is.na(eps) || (eps <= 0) || (eps >= 1))
     stop("'eps' must be in (0, 1)")
     
  if ((length(maxIter) != 1L) || is.na(maxIter) || (maxIter < 1) || (floor(maxIter) != ceiling(maxIter)))
     stop("maxIter' must be a positive integer")

  if (rhoe == 1)
   {
    barplot(c(1 - pe, rep(0, r), pe), names.arg = 0:(r + 1), ylim = c(0, 1), main = expression(rho[e]==1), ylab = "Prob", xlab = "Number of exposed periods")
   } else {
   	       if (rhoe == -1/r)
   	        {
   	         ei <- (r + 1) * pe
   	         probs <- rep(0, r + 2)
   	         probs[ei + 1] <- 1
   	         barplot(probs, names.arg = 0:(r + 1), ylim = c(0, 1), main = bquote(rho[e]==.(rhoe)), ylab = "Prob", xlab = "Number of exposed periods")
            } else {
            	    prevVec <- rep(pe, r + 1)
            	    exx <- matrix(rhoe * pe * (1 - pe) + pe^2, nrow = r + 1, ncol = r + 1)
            	    diag(exx) <- pe
            	    # True configurations
            	    k <- 1
            	    confsTrue <- list()
            	    for (i in 1:r)
            	     {
            	      for (j in (i + 1):(r + 1))
            	       {
            	       	confsTrue[[k]] <- c(1 - prevVec[i] - prevVec[j] + exx[i, j], prevVec[i] - exx[i, j], prevVec[j] - exx[i, j], exx[i, j])
            	       	k <- k + 1
            	       }
            	      }
            	     
                     # initialize
                     arglist <- vector("list", r + 1)
                     names(arglist) <- paste("v", 1:(r + 1), sep = "")
                     for (i in 1:(r + 1))
                      arglist[[i]] <- 0:1
                     table <- array(1, dim = rep(2, r + 1), dimnames = arglist)
                     iter <- 0
                     converged <- F
                     
                     if (r == 1)
                      {
                       confsIter <- table
                       ratio <- confsTrue[[1]]/confsIter
                       table <- table * ratio
                       iter <- 1 } else {
                       # Auxiliary stuff
                       l <- list()
                       for (i in 1:(r - 1))
                        l[[i]] <- 1:2
                       auxMat <- as.matrix(expand.grid(l))
                       ones <- matrix(1, ncol = 1, nrow = 2^(r - 1))
                       twos <- 2*ones
                     
                       # iteration
                       while (converged == F & iter < maxIter)
                        {
                         converged <- T
                         k <- 1
                         for (i in 1:r)
                          {
                           for (j in (i + 1):(r + 1))
                            {
                             indexSet <- insertCols(auxMat, i, j, ones, ones)
                             confsIter <- apply(table, c(i, j), sum)
                             ratio <- confsTrue[[k]]/confsIter
                             table[indexSet] <- table[indexSet] * ratio[1, 1]
                             indexSet <- insertCols(auxMat,i, j, twos, ones)
                             table[indexSet] <- table[indexSet] * ratio[2, 1]
                             indexSet <- insertCols(auxMat, i, j, ones, twos)
                             table[indexSet] <- table[indexSet] * ratio[1, 2]
                             indexSet <- insertCols(auxMat, i, j, twos, twos)
                             table[indexSet] <- table[indexSet] * ratio[2, 2]
                             k <- k + 1                   
                             converged <- (converged & abs(ratio[1, 1] - 1) < eps & abs(ratio[2, 1] - 1) < eps & abs(ratio[1, 2] - 1) < eps & abs(ratio[2, 2] - 1) < eps)
                            }
                          }
                         iter <- iter + 1
                        }
                      }
                     converged <- T
                     if (iter == maxIter)
                      converged <- F
                     f <- ftable(table, row.vars = 1:(r + 1))
                     arglist <- vector("list", r + 1)
                     for (i in 1:(r + 1))
                      arglist[[i]] <- 0:1
                     result <- do.call("expand.grid", arglist)
                     result2 <- result[, seq(r + 1, 1, by = -1)]
                     all <- cbind(result2, f = as.vector(f))
                     all$sum <- rowSums(all[, 1:(r + 1)])
                     distr <- aggregate(all$f, by = list(exposedPeriods = all$sum), "sum")
                     distrib <- cbind(exposedPeriods = distr$exposedPeriods, Prob = distr$x)
                     barplot(distrib[, 2], names.arg = 0:(r + 1), ylim = c(0, 1), main = bquote(rho[e]==.(rhoe)), ylab = "Prob", xlab = "Number of exposed periods")
                    }
           }
 }


