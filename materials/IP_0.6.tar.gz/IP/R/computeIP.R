computeIP <-
function(w, f, conf = 95, nsim = 5000, seed = 4321) UseMethod("computeIP")
