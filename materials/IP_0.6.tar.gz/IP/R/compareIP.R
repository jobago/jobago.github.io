compareIP <-
function(w, f1, f2, conf = 95, nsim = 5000, seed = 4321) UseMethod("compareIP")
