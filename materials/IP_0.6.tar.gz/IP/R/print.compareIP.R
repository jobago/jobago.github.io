print.compareIP <-
function(x, digits = 3, ...)
 {
  if(!inherits(x, "compareIP"))
   stop("argument 'x' must be of class 'compareIP'")
  
  cat("\n")
  cat("IP scores and ", x$conf, "% confidence interval based on ", x$nsim, " parametric bootstrap samples:\n", sep = "")
  IP1 <- round(x$IP["IP1", "Estimate"], digits)
  IP1lo <- round(x$IP["IP1", 2], digits)
  IP1up <- round(x$IP["IP1", 3], digits)
  cat("  Trial 1: ", IP1, " (", IP1lo, ", ", IP1up, ")\n", sep = "")
  
  IP2 <- round(x$IP["IP2", "Estimate"], digits)
  IP2lo <- round(x$IP["IP2", 2], digits)
  IP2up <- round(x$IP["IP2", 3], digits)
  cat("  Trial 2: ", IP2, " (", IP2lo, ", ", IP2up, ")\n", sep = "")
  
  IPdiff <- round(x$IP["IP1-IP2", "Estimate"], digits)
  IPdifflo <- round(x$IP["IP1-IP2", 2], digits)
  IPdiffup <- round(x$IP["IP1-IP2", 3], digits)
  cat("  Trial 1 - Trial 2: ", IPdiff, " (", IPdifflo, ", ", IPdiffup, ")\n\n", sep = "")
    
  cat("Hyphotesis test for the significance of the difference:\n")
  cat("  Null hyphotesis: performance profiles are the same in both trials.\n")
  cat("  Alternative hyphotesis: performance profiles are not equal.\n")
  cat("  p-value:", x$p.value, "\n")
 }
