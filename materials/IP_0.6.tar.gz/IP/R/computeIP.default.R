computeIP.default <-
function(w, f, conf = 95, nsim = 5000, seed = 4321)
 {
  if ((!inherits(w, "numeric") && !inherits(w, "integer")) || sum(is.na(w)) > 0)
    stop("argument 'w' must be a vector with numerical weights")
  
  if ((!inherits(f, "numeric") && (!inherits(f, "integer"))) || sum(is.na(f)) > 0)
    stop("argument 'f' must be a vector with trial 1 frequencies")
  
  if (sum(floor(f) != ceiling(f)) > 0)
    stop("values in 'f' must be non negative integers")
    
  if (min(f) < 0)
    stop("values in 'f' must be non negative integers")
  
  nw <- length(w)    
  if (length(f) != nw)
    stop("the number of frequencies must be equal to the number of weights in 'w'")
               
  if ((length(conf) != 1L) || is.na(conf) || (conf <= 0) || (conf >= 100))
    stop("the confidence level 'conf' must be between 0 and 100")
     
  if ((!inherits(nsim, "integer") && (!inherits(nsim, "numeric"))) || (length(nsim) != 1L) || is.na(nsim) || (nsim <= 0))
    stop("the number of simulations 'nsim' must be a positive integer")
         
  if ((!inherits(seed, "numeric")) || (length(seed) != 1L) || is.na(seed))
    stop("the argument 'seed' must be a number") 
 
  set.seed(seed)
  n <- sum(f)
  Ip <- sum(w * f)/n
  samps <- sapply(as.list(f), FUN = function(x) rpois(n = nsim, lambda = x))
  samps <- cbind(samps, rowSums(samps))
  simIPc <- apply(samps, 1, FUN = function(x) sum(w*x[1:nw])/x[nw + 1])
  simIC <- quantile(simIPc, probs = c((1 - conf/100)/2, (1 + conf/100)/2))
  IP <- c(Ip, simIC)
  names(IP)[1] <- c("Estimate")
  IP <- list(IP = IP, conf = conf, nsim = nsim)
  class(IP) <- "computeIP"
  IP
 }
