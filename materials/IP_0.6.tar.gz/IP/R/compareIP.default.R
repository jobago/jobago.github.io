compareIP.default <-
function(w, f1, f2, conf = 95, nsim = 5000, seed = 4321)
 {
  if ((!inherits(w, "numeric") && !inherits(w, "integer")) || sum(is.na(w)) > 0)
    stop("argument 'w' must be a vector with numerical weights")
  
  if ((!inherits(f1, "numeric") && (!inherits(f1, "integer"))) || sum(is.na(f1)) > 0)
    stop("argument 'f1' must be a vector with trial 1 frequencies")
  
  if (sum(floor(f1) != ceiling(f1)) > 0)
    stop("values in 'f1' must be non negative integers")
    
  if (min(f1) < 0)
    stop("values in 'f1' must be non negative integers")
  
  nw <- length(w)
  if (length(f1) != nw)
    stop("the number of frequencies for trial 1 must be equal to the number of weights in 'w'")
        
  if ((!inherits(f2, "numeric") && (!inherits(f2, "integer"))) || sum(is.na(f2)) > 0)
    stop("argument 'f2' must be a vector with trial 2 frequencies")
     
  if (sum(floor(f2) != ceiling(f2)) > 0)
    stop("values in 'f2' must be non negative integers")
    
  if (min(f2) < 0)
    stop("values in 'f2' must be non negative integers")
     
  if (length(f2) != nw)
    stop("the number of frequencies for trial 2 must be equal to the number of weights in 'w'")
     
  if ((length(conf) != 1L) || is.na(conf) || (conf <= 0) || (conf >= 100))
    stop("the confidence level 'conf' must be between 0 and 100")

  if ((!inherits(nsim, "integer") && (!inherits(nsim, "numeric"))) || (length(nsim) != 1L) || is.na(nsim) || (nsim <= 0))
    stop("the number of simulations 'nsim' must be a positive integer")
     
  if ((!inherits(seed, "numeric")) || (length(seed) != 1L) || is.na(seed))
    stop("the argument 'seed' must be a number")
  
  # point estimate and CI for IP1 (bootstrap sampling):
  n1 <- sum(f1)
  IP1 <- as.numeric(w %*% f1) / n1
  set.seed(seed)
  samps1 <- sapply(as.list(f1), FUN = function(x) rpois(n = nsim, lambda = x))
  samps1 <- cbind(samps1, rowSums(samps1))
  simIP1 <- apply(samps1, 1, FUN = function(x) as.numeric(w %*% x[1:nw])/x[nw + 1])
  IC1 <- quantile(simIP1, probs = c((1 - conf/100)/2, (1 + conf/100)/2))
  # point estimate and CI for IP2 (bootstrap sampling):
  n2 <- sum(f2)
  IP2 <- as.numeric(w %*% f2) / n2
  samps2 <- sapply(as.list(f2), FUN = function(x) rpois(n = nsim, lambda = x))
  samps2 <- cbind(samps2, rowSums(samps2))
  simIP2 <- apply(samps2, 1, FUN = function(x) as.numeric(w %*% x[1:nw])/x[nw + 1])
  IC2 <- quantile(simIP2, probs = c((1 - conf/100)/2, (1 + conf/100)/2))
  # point estimate and CI for IP1 - IP2 (using bootstrap sampling above):
  IPdiff <- IP1 - IP2
  simdIPdiff <- simIP1 - simIP2
  ICdiff <- quantile(simdIPdiff, probs = c((1 - conf/100)/2, (1 + conf/100)/2))
  # IP results:
  tab <- as.data.frame(rbind(c(IP1, IC1), c(IP2, IC2), c(IPdiff, ICdiff)))
  rownames(tab) <- c("IP1", "IP2", "IP1-IP2")
  colnames(tab)[1] <- "Estimate"
  # pvalue for the difference:
  # Poisson parameters under H0:
  lambdasH0 <- (f1 / n1 + f2 / n2) / 2
  lambdas1H0 <- lambdasH0 * n1
  lambdas2H0 <- lambdasH0 * n2
  # bootstrap sampling under H0:
  samps1H0 <- sapply(as.list(lambdas1H0), FUN = function(x) rpois(n = nsim, lambda = x))
  samps1H0 <- cbind(samps1H0, rowSums(samps1H0)) 
  samps2H0 <- sapply(as.list(lambdas2H0), FUN = function(x) rpois(n = nsim, lambda = x))
  samps2H0 <- cbind(samps2H0, rowSums(samps2H0))
  simIP1H0 <- apply(samps1H0, 1, FUN = function(x) as.numeric(w %*% x[1:nw])/x[nw + 1])
  simIP2H0 <- apply(samps2H0, 1, FUN = function(x) as.numeric(w %*% x[1:nw])/x[nw + 1])
  # expected absolute difference under H0:
  expdiff <- abs(simIP1H0 - simIP2H0)
  # observed absolute difference:
  obsdiff <- abs(IP1 - IP2)
  pval <- mean(expdiff >= obsdiff)
  res <- list(IP = tab, p.value = pval, conf = conf, nsim = nsim)
  class(res) <- "compareIP"
  res
 }
