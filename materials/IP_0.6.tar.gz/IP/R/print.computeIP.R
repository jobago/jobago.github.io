print.computeIP <-
function(x, digits = 3, ...)
 {
  if(!inherits(x, "computeIP"))
   stop("argument 'x' must be of class 'computeIP'")
  cat("\n")
  cat("IP:", round(x$IP["Estimate"], digits), "\n")
  lo <- as.numeric(round(x$IP[2], digits))
  up <- as.numeric(round(x$IP[3], digits))
  cat(x$conf, "% confidence interval based on ", x$nsim, " parametric bootstrap samples: (", lo, ", ", up, ")", sep = "")
 }
