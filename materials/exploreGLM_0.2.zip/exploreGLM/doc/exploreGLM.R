### R code from vignette source 'exploreGLM.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: exploreGLM.Rnw:43-44
###################################################
options(width = 80)


###################################################
### code chunk number 2: exploreGLM.Rnw:71-72 (eval = FALSE)
###################################################
## vignette("exploreGLM")


###################################################
### code chunk number 3: exploreGLM.Rnw:90-91
###################################################
library("exploreGLM")


###################################################
### code chunk number 4: exploreGLM.Rnw:95-96 (eval = FALSE)
###################################################
## ?exploreGLM


###################################################
### code chunk number 5: exploreGLM.Rnw:110-111 (eval = FALSE)
###################################################
## ?prepareData


###################################################
### code chunk number 6: exploreGLM.Rnw:157-158 (eval = FALSE)
###################################################
## ?exploreglm


###################################################
### code chunk number 7: exploreGLM.Rnw:189-190
###################################################
data(flowers)


###################################################
### code chunk number 8: exploreGLM.Rnw:200-201 (eval = FALSE)
###################################################
## ?flowers


###################################################
### code chunk number 9: exploreGLM.Rnw:225-226
###################################################
pDflo <- prepareData(data = flowers, id = idflo)


###################################################
### code chunk number 10: exploreGLM.Rnw:232-233 (eval = FALSE)
###################################################
## pDflo


###################################################
### code chunk number 11: exploreGLM.Rnw:237-238
###################################################
print(pDflo, lines = 18)


###################################################
### code chunk number 12: exploreGLM.Rnw:242-243
###################################################
summary(pDflo, digits = 1)


###################################################
### code chunk number 13: exploreGLM.Rnw:267-268
###################################################
modEVA <- exploreglm(EVA ~ ., object = pDflo)


###################################################
### code chunk number 14: exploreGLM.Rnw:273-274
###################################################
modEVA


###################################################
### code chunk number 15: exploreGLM.Rnw:279-280
###################################################
summary(modEVA)


###################################################
### code chunk number 16: exploreGLM.Rnw:287-288
###################################################
plot(modEVA)


###################################################
### code chunk number 17: exploreGLM.Rnw:304-307
###################################################
modcol <- exploreglm(color ~ treat + water + flower + petal, 
                     object = pDflo)
modcol


###################################################
### code chunk number 18: exploreGLM.Rnw:311-312
###################################################
summary(modcol)


###################################################
### code chunk number 19: exploreGLM.Rnw:319-320
###################################################
plot(modcol)


###################################################
### code chunk number 20: exploreGLM.Rnw:337-340
###################################################
moddefects <- exploreglm(defects ~ treat * flower + water + petal, 
                         object = pDflo, count = TRUE)
moddefects


###################################################
### code chunk number 21: exploreGLM.Rnw:344-345
###################################################
summary(moddefects)


###################################################
### code chunk number 22: exploreGLM.Rnw:352-353
###################################################
plot(moddefects)


###################################################
### code chunk number 23: exploreGLM.Rnw:370-372
###################################################
modpetal <- exploreglm(petal ~ treat + water + flower, 
                       object = pDflo, ordinal = TRUE)


###################################################
### code chunk number 24: exploreGLM.Rnw:376-377
###################################################
summary(modpetal)


###################################################
### code chunk number 25: exploreGLM.Rnw:382-386 (eval = FALSE)
###################################################
## plot(modpetal)
## 'Error in plot.exploreglm(modpetal): 
##   ordinal and nominal models does not have a defined plot in 
##   exploreGLM package'


###################################################
### code chunk number 26: exploreGLM.Rnw:399-400
###################################################
modtreat <- exploreglm(treat ~ ., object = pDflo)


###################################################
### code chunk number 27: exploreGLM.Rnw:404-405
###################################################
summary(modtreat)


###################################################
### code chunk number 28: exploreGLM.Rnw:410-414 (eval = FALSE)
###################################################
## plot(modtreat)
## 'Error in plot.exploreglm(modtreat) : 
##   ordinal and nominal models does not have a defined plot in 
##   exploreGLM package'


