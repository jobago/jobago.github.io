exploreglm <-
function(formula, object, ordinal = FALSE, count = FALSE)
 {

  if (!inherits(formula, "formula"))
    stop("argument 'formula' must be of class 'formula'")
  
  if (!inherits(object, "prepareData"))
   stop("argument 'object' must be of class 'prepareData'")
  
  if (ordinal == TRUE && count == TRUE)
   stop("only one of 'ordinal' or 'count' must be TRUE")
  
  y <- deparse(terms(formula, data = object$data)[[2]])
  ypos <- which(names(object$data) == y)
  ytype <- object$type[ypos]
  ynval <- object$nvalues[ypos]
    
  if (ynval < 2)
   stop("argument 'y' can not be a constant.")
  
  aux <- data.frame(cond = c("numericalFALSE", "numericalTRUE", "categoricalFALSE", "categoricalTRUE"), model = paste("fit", c("lm", "poisson", "multinomial", "ordinal"), sep = ""))
  if (ytype == "numerical")
   modtype <- as.character(aux$model[aux$cond == paste(ytype, count, sep = "")]) else
   modtype <- as.character(aux$model[aux$cond == paste(ytype, ordinal, sep="")]) 
   eval(parse(text = paste("res <- ", modtype, "(formula = formula, data = object$data, ynval = ynval)", sep = "")))
  
  class(res) <- "exploreglm"
  res
 }
