print.summary.exploreglm <-
function(x, ...)
 {

    y <- deparse(terms(x$formula, data = x$data)[[2]])  
    
    if(x$ytype != "Ordinal variable" && x$ytype != "Nominal variable") {
      
      cat("=========================================================================\n")
      cat("Dependent variable: ", y, " (", x$ytype, ")", "\n", sep = "")
      cat("Model type:", x$modtype, "\n") 
      cat("Model:", paste0(y," ~ ", paste(attributes(terms(x$formula, data=x$data))$term.labels, collapse= " + ")))
      cat("\n=========================================================================\n")
      #cat("Model: "); print(x$formula)
      #cat("=========================================================================\n")
      print(summary(x$mod, ...))      }
    
    
    if(x$ytype == "Ordinal variable" || x$ytype == "Nominal variable") {
            
      cat("=========================================================================\n")
      cat("Dependent variable: ", y, " (", x$ytype, ")", "\n", sep = "")
      cat("Model type:", x$modtype, "\n") 
      cat("Model:", paste0(y," ~ ", paste(attributes(terms(x$formula, data=x$data))$term.labels, collapse= " + ")))
      cat("\n=========================================================================\n")
      
      print(x$mod)                    }
 }
