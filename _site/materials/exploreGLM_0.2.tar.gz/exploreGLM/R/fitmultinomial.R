fitmultinomial <-
function(formula, data, ynval)
 {
  if (ynval == 2)  fitlogistic(formula = formula, data = data) else {
  	mod <- multinom(formula = formula, data = data)
    list(formula = formula, data = data, mod = mod, modtype = "Logistic regression model for polytomous nominal data", ytype = "Nominal variable")
  }
 }