fitordinal <-
function(formula, data, ynval)
 {
  if (ynval == 2)  fitlogistic(formula = formula, data = data) else {
  	mod <- polr(formula = formula, data = data)
  	list(formula = formula, data = data, mod = mod, modtype = "Logistic regression model for polytomous ordinal data", ytype = "Ordinal variable")
  }
 }
