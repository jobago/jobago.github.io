fitpoisson <-
function(formula, data, ynval)
 {
  mod <- glm(formula = formula, family = poisson, data = data)
  list(formula = formula, data = data, mod = mod, modtype = "Poisson regression model", ytype = "Count variable")
 }
