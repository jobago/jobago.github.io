plot.exploreglm <-
function (x, ...){
  
  
  if (!inherits(x, "exploreglm"))
    stop("argument 'x' must be of class 'exploreglm'")
  
  
  ytype <- x$ytype
  
  if (ytype == "Ordinal variable" || ytype == "Nominal variable")
    stop("ordinal and nominal models does not have a defined plot in exploreGLM package")
  
  par(mfrow=c(2,2), ...)
  plot(x$mod, ...)}
