summary.exploreglm <-
function(object, ...)
  {
   if (!inherits(object, "exploreglm"))
    stop("argument 'object' must be of class 'exploreglm'")
   
   res <- list(formula = object$formula, data = object$data, y = object$y, mod = object$mod, modtype = object$modtype, ytype = object$ytype) 
   class(res) <- c("list", "summary.exploreglm")
   res
  }
