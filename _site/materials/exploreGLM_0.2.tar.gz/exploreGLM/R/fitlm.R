fitlm <-
function(formula, data, ynval)
  {
   mod <- glm(formula = formula, family = gaussian, data = data)
   list(formula = formula, data = data, mod = mod, modtype = "Linear regression model", ytype = "Continuous variable")  
  }