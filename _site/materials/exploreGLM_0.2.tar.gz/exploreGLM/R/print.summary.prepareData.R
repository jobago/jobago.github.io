print.summary.prepareData <-
function(x, ...)
  {  
  smry <- x$smry
  data <- x$data
  nvars <- ncol(data)
  n <- nrow(data)
  nvalues <- x$nvalues
  numvars <- x$numvars
  digits <- x$digits  
  
  cat("=========================================================================\n")
  cat("Number of Variables: ", nvars, "    Observations: ", n, "\n")
  cat("Maximum number of categories in a numerical variable to be treated as", "\n")
  cat("categorical:", x$k, "\n")
  cat("=========================================================================\n")
  
  cat("Qualitative Variables:")
  cat("\n=======================")  
  
    for(i in 1:nvars) {
    
    if (is.factor(data[,i]))    {
    
      cat("\nVariable:", smry[[i]][[1]], ", ")
      cat("Missing values:", smry[[i]][[3]], " (", round(smry[[i]][[4]], digits),  "%)\n")

      
      mat <- rbind(c(smry[[i]][[6]], sum(smry[[i]][[6]])), c(smry[[i]][[7]], sum(smry[[i]][[7]])))
      colnames(mat)[nvalues[i]+1] <- "Total"
      rownames(mat) <- c("Frequencies","Percentages")
      print(round(mat, digits))
      cat("-------------------------------------------------------------------------")
                                  }
    
                      }
        
  
  matnum <- matrix(ncol = 13, nrow = numvars)
  colnames(matnum) <- c("nMiss", "%Miss", "Mean","SD" ,"Min", "2.5%", "5%", "Q1",
                          "Median", "Q3", "95%", "97.5%", "Max")
  
  rownames(matnum) <- character(numvars)
  
  rownum <- 0
    
  for(i in 1:nvars) {
        
    if (is.numeric(data[,i]))   {
       
      
      desc <- c(smry[[i]][[3]], smry[[i]][[4]], smry[[i]][[5]], smry[[i]][[6]], smry[[i]][[10]], smry[[i]][[7]], smry[[i]][[9]],
              smry[[i]][[8]], smry[[i]][[11]])
      
      rownum <- rownum + 1
      rownames(matnum)[rownum] <- smry[[i]][[1]]
        
      matnum[rownum,] <- desc   }
  
                    }
      
      if (numvars>0) 
                      cat("\nQuantitative Variables:")
                      cat("\n=======================\n")                  
                      print(round(matnum, digits))

  }
