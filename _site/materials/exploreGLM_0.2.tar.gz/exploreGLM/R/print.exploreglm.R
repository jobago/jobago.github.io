print.exploreglm <-
function(x, ...)
 {
  if (!inherits(x, "exploreglm"))
    stop("argument 'x' must be of class 'exploreglm'")
  
  y <- deparse(terms(x$formula, data = x$data)[[2]])
  
  cat("=========================================================================\n")
  cat("Dependent variable: ", y, " (", x$ytype, ")", "\n", sep = "")
  cat("Model type:", x$modtype, "\n") 
  cat("Model:", paste0(y," ~ ", paste(attributes(terms(x$formula, data=x$data))$term.labels, collapse= " + ")))
  cat("\n=========================================================================\n")
  cat("Further information about this model with summary()\n")    
 }
