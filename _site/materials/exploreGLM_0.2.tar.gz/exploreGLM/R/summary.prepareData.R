summary.prepareData <-
function(object, digits = 2, ...)
  {

      if (!inherits(object, "prepareData"))
      stop("argument 'object' must be of class 'prepareData'") 
  
      if (!inherits(digits, "numeric") || (inherits(digits, "numeric") && digits%%1!=0) || is.na(digits) || digits<=0)
      stop("argument 'digits' must be a positive integer.")
      
    data <- object$data
    nvalues <- object$nvalues
    nvars <- dim(data)[2]
    smry <- vector("list", nvars)
    numvars <- 0

    
    for (i in 1:nvars)
    {
      if (is.factor(data[,i])==T){
          
        smry[[i]] <- vector("list", 7)
        smry[[i]][[1]] <- names(data)[i]
        smry[[i]][[2]] <- length(data[,i])
        smry[[i]][[3]] <- sum(is.na(data[,i]))
        smry[[i]][[4]] <- (smry[[i]][[3]] / smry[[i]][[2]]) * 100
        smry[[i]][[5]] <- sort(unique(data[,i]))
        smry[[i]][[6]] <- table(data[,i])
        smry[[i]][[7]] <- (table(data[,i])/sum(table(data[,i])))*100
                                  } 
      
      
      if (is.numeric(data[,i])==T){
        
        smry[[i]] <- vector("list", 11)
        smry[[i]][[1]] <- names(data)[i]
        smry[[i]][[2]] <- length(data[,i])
        smry[[i]][[3]] <- sum(is.na(data[,i]))
        smry[[i]][[4]] <- (smry[[i]][[3]]/smry[[i]][[2]])*100
        smry[[i]][[5]] <- mean(na.omit(data[,i]))
        smry[[i]][[6]] <- sd(na.omit(data[,i]))
        smry[[i]][[7]] <- quantile(na.omit(data[,i]),c(0.025,0.05,0.25))
        smry[[i]][[8]] <- quantile(na.omit(data[,i]),c(0.75,0.95,0.975))
        smry[[i]][[9]] <- median(na.omit(data[,i]))
        smry[[i]][[10]] <- min(na.omit(data[,i]))
        smry[[i]][[11]] <- max(na.omit(data[,i]))
        numvars <- numvars + 1                  
                                  } 
       
    }
    
    res <- list(smry = smry, data = data, nvalues = nvalues, numvars = numvars, k=object$k, digits = digits) 
    class(res) <- c("list", "summary.prepareData")
    res
  }
