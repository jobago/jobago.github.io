print.prepareData <-
function(x, lines = 10, ...)
  {
   if (!inherits(x, "prepareData"))
      stop("object 'x' must be of class 'prepareData'.")
   
   if (!inherits(lines, "numeric") || (inherits(lines, "numeric") && lines%%1!=0) || is.na(lines) || lines<=0 || lines > nrow(x$data))
     stop("argument 'lines' must be a positive integer and less than total of observations.")
   
   vars <- data.frame(names(x$data), x$type, x$nvalues)
   names(vars) <- c("Name", "Type", " Different values")
   cat("Variables (those with are least", x$k+1, "different numerical values are assumed")
   cat("\nto be numerical):\n")
   print(vars)
   cat("\n")
   cat("Printing the ", lines, " first records:\n")
   print(x$data[1:lines,], ...)
  }
