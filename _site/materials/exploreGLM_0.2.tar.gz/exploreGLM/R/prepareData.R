prepareData <-
function(data, k = 5, id = NULL)
  {
  
    id <- deparse(substitute(id))
  
  if (!inherits(data, "data.frame"))
    stop("argument 'data' must be a data.frame.")
  
  if (!inherits(k, "numeric") || (inherits(k, "numeric") && k%%1!=0) || is.na(k) || k<=0)
    stop("argument 'k' must be a positive integer.")
  
  if (is.null(id))
    warning("id is NULL, all variables are going to be consider in the analysis.")
  
  if (!is.null(id)) {
    
    if (!inherits(id, "character") || !any(id %in% names(data)))
      stop("argument 'id' does not match with any variable name.")
    
    id <- which(names(data) == id)
    data <- data[, -id]}
  
  
  nvar <- ncol(data)
  nvalues <- rep(NA, nvar)
  type <- rep(NA, nvar)
  
  
  for (i in 1:nvar)
  {
    x <- data[, i] 
    nvalues[i] <- length(table(x))
    
    if ((class(x) == "character") || is.factor(x)  || (nvalues[i] <= k)) {
      data[, i] <- as.factor(data[, i])
      type[i] <- "categorical" }
    else {
      data[, i] <- as.numeric(data[, i])
      type[i] <- "numerical" }
  }
  
  res <- list(data = data, nvalues = nvalues, type=type, k=k)
  class(res) <- c("list", "prepareData")
  res
  
  }
