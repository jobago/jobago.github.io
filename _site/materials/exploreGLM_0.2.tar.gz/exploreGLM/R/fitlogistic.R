fitlogistic <-
function(formula, data)
 {
  mod <- glm(formula = formula, family = binomial, data = data)
  list(formula = formula, data = data, mod = mod, modtype = "Logistic regression model", ytype = "Dichotomous variable")
 }
